package basics;

import java.util.*;
class customer1
{
	String name,address;
	int id;
	
	void customer_data()
	{
		Scanner s  =new Scanner(System.in);
		
		System.out.println("Enter the Customer Id");
		id=s.nextInt();
		System.out.println("Enter the Customer Name");
		name=s.next();
		
		System.out.println("Enter the Customer Address");
		address=s.next();
		
	}
	
	void cus_report()
	{
		System.out.println(" Customer Id:"+id);
		System.out.println(" Customer Name:"+name);
		System.out.println(" Customer Address:"+address);

	}
}

class product extends customer1
{
	String name;
	int id,price;
	
	void product_data()
	{
		Scanner s  =new Scanner(System.in);
		
		System.out.println("Enter the Product Id");
		id=s.nextInt();
		System.out.println("Enter the Product Name");
		name=s.next();
		
		System.out.println("Enter the Product Price");
		price=s.nextInt();
		
	}
	
	void product_report()
	{
		System.out.println(" Product Id:"+id);
		System.out.println(" Product Name:"+name);
		System.out.println(" Product Price:"+price);

	}
}

class Accounts extends product
{
	String acc_type;
	int acc_no,balance_amt;
	
	void accounts_data()
	{
		Scanner s  =new Scanner(System.in);
		
		System.out.println("Enter the Account Number");
		acc_no=s.nextInt();
		System.out.println("Enter the Account Type");
		acc_type=s.next();
		
		System.out.println("Enter the Account Balance ");
		balance_amt=s.nextInt();
		
	}
	
	void accounts_report()
	{
		System.out.println(" Account Number:"+acc_no);
		System.out.println(" Account Type:"+acc_type);
		System.out.println(" Account Balance:"+balance_amt);

	}
}




public class multi_level {

	public static void main(String[] args) 
	{
	
		Accounts a =new Accounts();
		
		a.customer_data();
		a.cus_report();
		
		a.product_data();
		a.product_report();
		
		a.accounts_data();
		a.accounts_report();
	}

}
