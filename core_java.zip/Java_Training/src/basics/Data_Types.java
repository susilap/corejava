 package basics;

public class Data_Types
{
	public static void main(String args[])
	{
		System.out.println("Student Details");
		short rno=111;
		float m1,m2,m3,tot,avg;
		m1=56;
		m2=89;
		m3=79;
		tot=m1+m2+m3;
		avg=tot/3;
		String name="Sachin";
		long aadhar=456475342354L;
		boolean passed=true;
		
		System.out.println("RegNo:"+rno);
		System.out.println("Name:"+name);
		System.out.println("Aadhar No:"+aadhar);
		System.out.println("Mark1:"+m1);
		System.out.println("Mark2:"+m2);
		System.out.println("Mark3:"+m3);
		
		System.out.println("total:"+tot);
		System.out.println("Result:"+passed);
		
		
	}

}
