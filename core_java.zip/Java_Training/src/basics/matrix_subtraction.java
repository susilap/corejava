package basics;

import java.util.Scanner;

public class matrix_subtraction
{
	public static void main(String[] args) 
	{
		int r,c;
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the row size");
		r =s.nextInt();
		System.out.println("Enter the col size");
		c=s.nextInt();
		
		int a[][]=new int[r][c];
		int b[][]=new int[r][c];
		int result[][]=new int[r][c];
		
		System.out.println("Enter the 1st matrix values");
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
			a[i][j]=s.nextInt();
			}
		}

		
		System.out.println("Enter the 2nd matrix values");
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
			b[i][j]=s.nextInt();
			}
		}
		
		
		System.out.println("Adding Matrix");
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
			result[i][j]=a[i][j]-b[i][j];
			}
		}

		System.out.println("Result");
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
			System.out.print(result[i][j]+"\t");
			}
			System.out.println();
		}


	}


}
