package basics;

class Person
{
   final long aadhar=895665483366l;
  String name="sridhar";
	
}
public class final_variable {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Person p =new Person();
		
		//p.aadhar=987456355666l;
		System.out.println("Aadhar:"+p.aadhar);

	}

}
