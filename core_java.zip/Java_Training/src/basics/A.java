package basics;

public class A {

	protected void msg()
	{
		System.out.println("Hello frm parent");
	}
}
