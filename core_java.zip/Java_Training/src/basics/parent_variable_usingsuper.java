package basics;

class Animal
{
	String color="white";
}
class Dog extends Animal
{
	String color="Black";
	
	void printColor()
	{
		System.out.println("child color:"+color);
		System.out.println("parent color:"+super.color);
	}
}
public class parent_variable_usingsuper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d =new Dog();
		d.printColor();

	}

}
