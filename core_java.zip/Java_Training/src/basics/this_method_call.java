package basics;
class studentt
{
	int rollno;
	String name;
	float fee;
	studentt(int rollno,String name,float fee)
	{
		this.rollno=rollno;
		this.name=name;
		this.fee=fee;
	}
	
	void display()
	{
		System.out.println(rollno+" "+name+" "+fee);
	}
}
public class this_method_call {

	public static void main(String[] args) 
	{
		studentt s1 =new studentt(111,"Arun",5000f);
		studentt s2 =new studentt(112,"Sumit",6000f);
		
		s1.display();s2.display();
	}

}

