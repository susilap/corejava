package basics;

public class cmd_line_argument {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		for(int i=0;i<args.length;i++) {
		System.out.println("your first argument is :"+args[i]);}
		

	}

}
