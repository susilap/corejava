package basics;

class c1
{
 private int x;
 
 void show()
 {
	 System.out.println("x="+x);
 }
}


public class private_ex {

	public static void main(String[] args)
	{
		c1 o =new c1();
		
		//o.x=100;
		o.show();
		//System.out.println(o.x);
		

	}

}
