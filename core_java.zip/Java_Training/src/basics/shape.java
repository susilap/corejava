package basics;

import java.util.Scanner;

class circle
{
	float pi,r;
	
	circle() // default constructor
	{
		System.out.println("Default constructor called");

	}
	
	circle(float r,float pi) //Parameterized constructor
	{
		this.r=r;
		this.pi=pi;
	}
	
	void area()
	{
		float area=pi*r*r;
		System.out.println("Area of the circle:"+area);
	}
	
	void circum()
	{
		float cir=2*pi*r;
		System.out.println("Circumference of the circle:"+cir);
	}
}
public class shape {

	public static void main(String[] args) 
	{
		circle c =new circle(42.6f,3.14f);
		circle c1 =new circle();
		c.area();
		c.circum();

	}

}
