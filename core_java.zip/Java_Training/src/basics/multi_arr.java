package basics;

import java.util.Scanner;

public class multi_arr {

	public static void main(String[] args) 
	{
		int r,c;
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the row size");
		r =s.nextInt();
		System.out.println("Enter the row size");
		c=s.nextInt();
		
		int x[][]=new int[r][c];
		System.out.println("Enter the array Values");
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
			x[i][j]=s.nextInt();
			}
		}
		
		System.out.println("Matrix values are");
		
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
			System.out.print(x[i][j]+"\t");
			}
			System.out.println();
		}


	}

}
