package basics;

class Acc
{
	static int acc_no;
	static String name,acc_type;
	 long aadhar=2244896985127l;
	
	void display()
	{
		System.out.println("Account Number:"+acc_no);
		System.out.println("Account Name:"+name);
		System.out.println("Account Type:"+acc_type);
	}
	
	static void show()
	{
		System.out.println("Account Number:"+acc_no);
		System.out.println("Account Name:"+name);
		System.out.println("Account Type:"+acc_type);
	}
	
}
public class static_ex 
{

	public static void main(String[] args)
	{
		Acc obj =new Acc();
		
		Acc.acc_no=1011;
		obj.name="name1";
		obj.acc_type="current";
		
		System.out.println("Acc Number:"+Acc.acc_no);

		System.out.println("Aadhaar Number before changing:"+obj.aadhar);
		//obj.aadhar=456989753214l;
		System.out.println("Aadhaar Number after changing:"+obj.aadhar);
	
		obj.display();
		Acc.show();
		
		
	}

}
