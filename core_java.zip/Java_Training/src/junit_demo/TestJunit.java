package junit_demo;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TestJunit 
{
@Test
public void testAdd()
{
	String s1="Junit test demo";
	assertEquals("Junit test demo",s1);
}
}
