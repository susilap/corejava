package demo;
import basics.*;

public class B  extends A{

	public static void main(String[] args) {
		
		B obj =new B();
		
		obj.msg();

	}

}
