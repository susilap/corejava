package pkg2;

import basics.armstrong_num;

public class public_ex {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		armstrong_num obj =new armstrong_num();
		obj.arm_strong(470);
		obj.arm_strong(153);
		obj.arm_strong(701);

	}

}
