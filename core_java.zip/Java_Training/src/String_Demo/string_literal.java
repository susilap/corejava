package String_Demo;

public class string_literal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1="Hello World";
		String s2="Hello World";
		
		System.out.println(s1);
		System.out.println(s2);

	}

}
