package String_Demo;

import java.util.Arrays;

public class str_methods {

	public static void main(String[] args) 
	{
		String s="SachinTendulkar";
		String s1="        SachinTendulkar   ";
		
		System.out.println("Original String:"+s);
		System.out.println("Sub String from index6:"+s.substring(6)); // Tendulkar
		System.out.println("Sub String from index 0 to 6:"+s.substring(0,6)); // Sachin
		
		String msg =new String("Hello, Good Evening To Every One");
		
		String text[]=msg.split(",");
		System.out.println(Arrays.toString(text));// [Hello Good Evening to Every one]
		System.out.println(s.toUpperCase()); //
		System.out.println(s.toLowerCase());
		System.out.println(s1);
		System.out.println(s1.trim());
		System.out.println(s.startsWith("Sa")); //t 
		System.out.println(s.endsWith("r"));// t
		System.out.println(s.charAt(6)); // T
		System.out.println(s.charAt(10));//u
		System.out.println(s.length());//
		System.out.println(s.replace("Sachin", "Tendulkar"));
	}

}
