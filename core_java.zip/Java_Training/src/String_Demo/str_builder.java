package String_Demo;

public class str_builder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder s= new StringBuilder("Hello World");
		StringBuilder s1= new StringBuilder("Hello");
		s.append(" Java");
		System.out.println(s);
		s.insert(1,"Java");
		System.out.println(s);
		s.replace(1, 3, "Buffer");
		System.out.println(s);
		s.delete(1, 3);
		System.out.println(s);
		s.reverse();
		System.out.println(s);
		System.out.println(s1.capacity());
		s1.append("java string is my favourite topic in core java");
		System.out.println(s1.capacity());
		
		s1.append("java string is my favourite topic in core java");
		System.out.println(s1.capacity());


	}

}
