package String_Demo;

public class str 
{

	public static void main(String args[])
	{
		System.out.println("hi"+" "); // hi hello
		
		System.out.println(100+" hello"); // 100 hello
		
		System.out.println("hello"+ 50+30); // hello 5030
		System.out.println(30+50+"hello"+ 50+30); // 80hello5030
		
	}
}
