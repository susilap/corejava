package Multi_thread_Demo;

public class garbage_collecion 
{
	public void finalize()
	{
		System.out.println("object is garbage collected");
	}

	public static void main(String[] args) {
		
		garbage_collecion s1 =new garbage_collecion();
		garbage_collecion s2 =new garbage_collecion();
		
		s1=null;
		s2=null;
		System.gc();

	}

}

