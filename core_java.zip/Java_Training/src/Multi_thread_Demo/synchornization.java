package Multi_thread_Demo;

class Table
{
      synchronized void printTable(int n)
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println(n*i);
			try
			{
				Thread.sleep(1000);
			}catch(Exception e) {System.out.println(e);}
		}
	}
}

class myThread1 extends Thread
{
Table t;
	myThread1(Table t)
	{
	this.t=t;	
	}
	
	public void run()
	{
		t.printTable(5);
	}
}

public class synchornization  {

	public static void main(String[] args)
	{
	Table obj = new Table();
	myThread1 t1 =new myThread1(obj);
	myThread1 t2 =new myThread1(obj);
	myThread1 t3=new myThread1(obj);
			
	t1.start();
	t2.start();
	t3.start();
	}

}
