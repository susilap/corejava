package Multi_thread_Demo;

class multi1 implements Runnable
{
	public void run()
	{
		for(int i=0;i<5;i++) 
		{
			System.out.println(i);
		}
	}
}
public class Runnable_demo {

	public static void main(String[] args)
	{
		
		multi1 t1 =new multi1();
		Thread thread1 =new Thread(t1);
		thread1.start();

	}

}
