package file_handling;

import java.io.*;
public class file_input {

	public static void main(String[] args) throws Exception
	{
		byte b[]= {35,36,37,38};
		
		ByteArrayInputStream byt=new ByteArrayInputStream(b);
		
		int k=0;
		while((k=byt.read())!=-1)
		{
			char ch=(char)k;
			
			System.out.println("Ascii for k:"+k+" ; special character is: "+ch);
		}

	}

}
