package file_handling;

import java.io.*;
public class buff_output {

	public static void main(String[] args) throws IOException
	{
		FileOutputStream fout = new FileOutputStream("C:\\testout.txt");
		
		BufferedOutputStream bout= new BufferedOutputStream(fout);
		
		String s="buffered output demo";
		
		byte b[]=s.getBytes();
		
		bout.write(b);
		
		bout.flush();
		bout.close();
		System.out.println("success");

	}

}
