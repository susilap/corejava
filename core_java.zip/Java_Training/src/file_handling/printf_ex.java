package file_handling;

public class printf_ex {

	public static void main(String[] args) 
	{
	int a=20;

	System.out.printf("%d\n",a);
	System.out.println(a);

	}

}
