package file_handling;

import java.io.*;


public class file_writer  {

	public static void main(String[] args)
	{
		try {
			
			FileWriter fw =new FileWriter("C:\\file_writer_demo.txt");
			
			fw.write("Data written using file writer");
			fw.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
		System.out.println("success");

	}

}
