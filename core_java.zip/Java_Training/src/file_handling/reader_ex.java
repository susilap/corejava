package file_handling;

import java.io.*;
public class reader_ex {

	public static void main(String[] args) 
	{
		try {
		InputStream s =new FileInputStream("C:\\test123.txt");
		
		Reader r =new InputStreamReader(s);
		
		int data=r.read();
		
		while(data!=-1)
		{
			System.out.print((char)data);
			data=r.read();
		}
		}catch(Exception e)
		{
			System.out.println(e);
		}

	}

}
