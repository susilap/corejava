package file_handling;

import java.io.*;
public class byte_array {

	public static void main(String[] args) 
	{
	try {
		FileOutputStream fout = new FileOutputStream("C:\\byteArray.txt");
		
		String s="Welcome to java Stream";
		
		byte b[]=s.getBytes();
		
		fout.write(b);
		
		fout.close();
		System.out.println("success");
	}catch(Exception e)
	{
		System.out.println(e);
	}

	}

}
