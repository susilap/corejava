package jdk8_Features;

import java.util.Optional;
public class null_pointer {

	public static void main(String[] args) 
	{
	String s[]=new String[10];
	

//	String lower_case =s[5].toLowerCase();
//	System.out.println(lower_case);
	
	
	Optional<String> checkNull=Optional.ofNullable(s[5]);
	if(checkNull.isPresent())
	{
		String lower_case =s[5].toLowerCase();
		System.out.println(lower_case);


	}
	else
	{
		System.out.println("String value is not present");
	}
	

	}

}
