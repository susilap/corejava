package jdk8_Features;

interface Addable
{
	int add(int a,int b);

	
}
public class lambda2 {

	public static void main(String[] args) 
	{
		
		Addable a1=(a,b)->(a*b);
		
		System.out.println(a1.add(20,39));
		
		Addable ad2=(int a,int b)->{
			return (a+b);
		};
		
		System.out.println(ad2.add(200, 800));
		

	}

}
