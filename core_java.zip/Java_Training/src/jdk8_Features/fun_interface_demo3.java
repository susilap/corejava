package jdk8_Features;

interface sayable
{
	void say(String msg);
	
	int hashCode();
//	
}
public class fun_interface_demo3 implements sayable {
	
	public void say(String msg) 
	{
		System.out.println("Hello :"+msg);
		
	}
	
//	@Override
//	public boolean equals() {
//		// TODO Auto-generated method stub
//		return false;
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		fun_interface_demo3 obj =new fun_interface_demo3();
		obj.say("World");
		
	}

	
}