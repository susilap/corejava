package jdk8_Features;

interface Drawable{
	
	public void draw();
}

public class lamda_expression {

	public static void main(String[] args) 
	{
	
		int width=10;
		
		Drawable d =()->
			{
				System.out.println("drawing:"+width);
			};
		
		d.draw();
		

	}

}
