package jdk8_Features;

interface ex1
{
	void display();
	
	default void show()
	{
		System.out.println("default method from interface introduced in jdk8");
	}
	
	static void static_demo()
	{
		System.out.println("static method from interface introduced in jdk8");

	}
}
public class default_method_ex implements ex1{
	
	public void display()
	{
		System.out.println("Abstract method from interface");
	}

	public static void main(String[] args) 
	{
	default_method_ex d =new default_method_ex();
	
	d.display();
	d.show();
	ex1.static_demo();
	}

}
