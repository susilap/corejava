package jdk8_Features;

interface shape
{
	public void square();
}
public class funtional_interface {

	public static void main(String[] args) 
	{
		
		shape s =new shape() {
			
			public void square()
			{
				System.out.println("Square is drawing....");
			}
		};
		
		s.square();

		s.square();

	}

}
