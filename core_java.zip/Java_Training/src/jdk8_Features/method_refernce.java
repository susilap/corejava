package jdk8_Features;

interface Sayable123
{
	void say();
}
public class method_refernce {

	public static void saySomething()
	{
		System.out.println("hi from static method");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Sayable123 s = method_refernce::saySomething;
		
		s.say();

	}

}
