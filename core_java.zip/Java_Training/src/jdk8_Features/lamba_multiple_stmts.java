package jdk8_Features;

@FunctionalInterface
interface Sayable
{
	String say(String msg);
}
public class lamba_multiple_stmts {

	public static void main(String[] args) 
	{
	
		Sayable person = (msg) ->
		{
			String s1="I would like to say";
			String s2=s1+msg;
			
			return s2;
		};
		
		System.out.println(person.say("time is precious"));

	}

}
