package jdk8_Features;

import java.util.*;
public class for_each {

	public static void main(String[] args) 
	{
	
		List<String> games =new ArrayList<String>();
		games.add("FootBall");
		games.add("Cricket");
		games.add("Chess");
		games.add("Hockey");
		
		System.out.println("with lambda expression");
		games.forEach(g->System.out.println(g));
		
		System.out.println("without lambda expression");
		for(String s:games)
		{
			System.out.println(s);
		}

		System.out.println("for each2");
		games.forEach(System.out::println);

		
	}

}
