package jdk8_Features;

interface Messageable
{
	Message getMessage(String msg);
}

class Message
{
	Message(String msg)
	{
		System.out.println("Hello:"+msg);
	}
}
public class method_ref_constructor {

	public static void main(String[] args) 
	{
	Messageable m = Message::new;
	
	m.getMessage("welcome");
	

	}

}
