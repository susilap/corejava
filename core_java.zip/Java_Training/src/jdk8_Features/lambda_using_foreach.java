package jdk8_Features;

import java.util.*;
public class lambda_using_foreach {

	public static void main(String[] args) 
	{
	
	ArrayList list =new ArrayList();
	
	list.add("ankit");
	list.add("Anu");
	list.add("pooja");
	list.add("sangeetha");
	list.add("amritha");
	
	list.forEach(
			(n)->System.out.println(n)
			
			);

	}

}
