package jdk8_Features;

interface Drawable1{
	
	public void draw(String name);
}

public class lambda_exp {

	public static void main(String[] args)
	{
	
		Drawable1 d=(name) ->{
			System.out.println("drwing the :"+name);
		};
		
		d.draw("Circle");
	}

}
