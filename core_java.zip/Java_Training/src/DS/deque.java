package DS;

import java.util.*;
public class deque {

	public static void main(String[] args)
	{
		Deque<String> d =new ArrayDeque<String>();
		
		d.add("Ravi");
		d.add("Vijay");
		d.add("Ajay");
		
		for(String s:d)
		{
		System.out.println(s);
		}
		d.offerFirst("jai");
		d.offerLast("kalai");

		System.out.println("After Adding First");

		for(String s:d)
		{
		System.out.println(s);
		}
		
		d.pollLast();
		d.pollFirst();
		System.out.println("After poll last");

		for(String s:d)
		{
		System.out.println(s);
		}
		
		
	}

}
