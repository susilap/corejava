package DS;

import java.util.*;
import java.util.Collections;

public class linked_list_method {

	public static void main(String[] args) {
LinkedList al =new LinkedList();
		
		System.out.println("is Array List is Empty:"+al.isEmpty());
		System.out.println(" Array List size:"+al.size());
		al.add("Ravi");
		al.add("Vijay");
		al.add("Ajay");
		
		System.out.println("After Add method:"+al);
		System.out.println("is Array List is Empty:"+al.isEmpty());
		
		al.add(1,"Gaurav");
		System.out.println("After Adding 1st index :"+al);
		
		LinkedList al2=new LinkedList();
		al2.add("sonoo");
		al2.add("Hanumath");
		
		al.addAll(al2);
		System.out.println("After Adding 1st index :"+al);
		
		LinkedList al3=new LinkedList();
		al3.add("Rahul");
		al3.add("John");
		
		al.addAll(1,al3);
		
		System.out.println("After Adding  :"+al);

		al.addFirst("Lokesh");
		System.out.println("After Adding  :"+al);
		al.addLast("Harsh");
		System.out.println(" Array List size:"+al);
		
		Collections.sort(al);
		System.out.println(" Ascending Order:"+al);
		
		Collections.sort(al,Collections.reverseOrder());
		System.out.println(" Decending Order:"+al);

	}

}
