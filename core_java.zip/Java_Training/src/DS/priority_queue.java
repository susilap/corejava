package DS;

import java.util.*;
public class priority_queue {

	public static void main(String[] args) {
	PriorityQueue p =new PriorityQueue();
	
p.add("Amit");
p.add("Vijay");
	p.add("Karan");
	p.add("Jai");
	p.add("Ram");
	p.add("Abdul");
	
	System.out.println("Head:"+p.element());
	System.out.println("Head:"+p.peek());
	
	Iterator i =p.iterator();
	while(i.hasNext())
	{
		System.out.println(i.next());
	}
	
	p.remove();
	p.poll();
	
	System.out.println("After Remove"+p);
	
	}
	
	
	

}
