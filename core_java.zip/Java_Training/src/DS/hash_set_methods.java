package DS;

import java.util.*;
public class hash_set_methods {

	public static void main(String[] args) 
	{
		
	HashSet<String> hs =new HashSet<String>();
	
	hs.add("Ravi");
	hs.add("Vijay");
	hs.add("Arun");
	hs.add("sumith");
	
	System.out.println("updated set:"+hs);
	
	hs.remove("Ravi");
	System.out.println("updated set:"+hs);
	
	HashSet<String> hs1 =new HashSet<String>();
	
	hs1.add("Ajay");
	hs1.add("Gaurav");
	
	hs.addAll(hs1);
	
	System.out.println("after add all set:"+hs);

	hs.removeAll(hs1);
	
	System.out.println("after remove all set:"+hs);
	
	hs.removeIf(str->str.contains("Vijay"));
	System.out.println("after removing ajay set:"+hs);

	hs.clear();
	System.out.println("After clear:"+hs);


	}

}

