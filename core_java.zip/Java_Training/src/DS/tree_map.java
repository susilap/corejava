package DS;

import java.util.*;

public class tree_map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeMap m =new TreeMap();
		m.put(1, "Amit");
		m.put(8, "Rahul");
		m.put(3, "Jai");
		m.put(4, "Amit");
		
		Set s =m.entrySet();
		
		Iterator i =s.iterator();
		
		while(i.hasNext())
		{
			Map.Entry entry =(Map.Entry)i.next();
			System.out.println(entry.getKey()+"  "+entry.getValue());
		}




	}

}
