package DS;

import java.util.*;
public class linked_hash_set {

	public static void main(String[] args) {
		//it contains unique values , null values allowed , not thread safe,insertion order

		LinkedHashSet lhs =new LinkedHashSet();
		lhs.add("JAVA");
		lhs.add("JSP");
		lhs.add("Spring");
		lhs.add("Hibernate");
		lhs.add("JAVA");
		lhs.add("Html");
		lhs.add(null);
		
		Iterator i =lhs.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}

}
