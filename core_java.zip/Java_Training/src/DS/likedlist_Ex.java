package DS;

import java.util.*;
import java.util.Iterator;

public class likedlist_Ex {

	public static void main(String[] args) 
	{
LinkedList list =new LinkedList();
		
		list.add(101);
		list.add("Books");
		list.add(1999.00);
		list.add(101);
		list.add("Books");
		list.add(1999.00);
		
		System.out.println(list);
		
		System.out.println("5th element"+list.get(5));
		list.set(4, "Fruits");
		System.out.println(list);


		Iterator itr= list.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());

		}
}

}
