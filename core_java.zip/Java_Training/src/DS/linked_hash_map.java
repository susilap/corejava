package DS;

import java.util.*;
public class linked_hash_map {

	public static void main(String[] args) 
	{
		LinkedHashMap m =new LinkedHashMap();
		m.put(1, "Amit");
		m.put(8, "Rahul");
		m.put(3, "Jai");
		m.put(4, "Amit");
		
		Set s =m.entrySet();
		
		Iterator i =s.iterator();
		
		while(i.hasNext())
		{
			Map.Entry entry =(Map.Entry)i.next();
			System.out.println(entry.getKey()+"  "+entry.getValue());
		}



	}

}
