package DS;

import java.util.*;

public class map_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Map m =new HashMap();
	m.put('A', "Amit");
	m.put('B', "Rahul");
	m.put('3', "Jai");
	m.put('4', "Amit");
	
	Set s =m.entrySet();
	
	Iterator i =s.iterator();
	
	while(i.hasNext())
	{
		Map.Entry entry =(Map.Entry)i.next();
		System.out.println(entry.getKey()+"  "+entry.getValue());
	}

	}

}
