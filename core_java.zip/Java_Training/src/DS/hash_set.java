package DS;
import java.util.*;

public class hash_set {

	public static void main(String[] args) 
	{
		//hash set unique values
		//allows null values
		//does't maintain insertion order
		// best approach for search
		
		HashSet<String> h =new HashSet();
		h.add("one");
		h.add("two");
		h.add("three");
		h.add("four");
		h.add("five");
		h.add("five");
		//h.add(null);
		
		Iterator i =h.iterator();
		
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		
		System.out.println("before Removing"+h);
		
		h.remove("four");
		
		System.out.println("After Removing"+h);
		h.removeIf(str->str.contains("two"));
		System.out.println("After Removing"+h);

	}

}
