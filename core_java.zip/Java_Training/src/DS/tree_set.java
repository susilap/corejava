package DS;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import java.util.*;
public class tree_set {

	public static void main(String[] args) {
		
		TreeMap m =new TreeMap();
		m.put(1, "Amit");
		m.put(4, "Rahul");
		m.put(3, "Jai");
		m.put(2, "Banu");
		
		Set s =m.entrySet();
		
		Iterator i =s.iterator();
		
		while(i.hasNext())
		{
			Map.Entry entry =(Map.Entry)i.next();
			System.out.println(entry.getKey()+"  "+entry.getValue());
		}

		// TODO Auto-generated method stub

	}

}
