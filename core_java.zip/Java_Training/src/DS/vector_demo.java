package DS;

import java.util.*;

public class vector_demo {

	public static void main(String[] args) {
		
		Vector v =new Vector();
		
		v.add(56);
		v.add("tiger");
		v.add(56.96);
		
		System.out.println(v);
		v.remove(0);
		System.out.println(v);

	}

}

