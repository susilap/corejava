package DS;

import java.util.*;

public class tree_set_ex {

	public static void main(String[] args)
	{
//unique elements , veryfast , null is not allowed , it maintains acending order
		//not thread safe
		
	TreeSet ts =new TreeSet();
		ts.add("Roxy");
		ts.add("Roxy");
		ts.add("Sandy");
		ts.add("Munish");
		ts.add("Pradeep");
		//ts.add(null);
		
		System.out.println(ts);
	
		Iterator i =ts.descendingIterator();
		
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		
		TreeSet ts1 =new TreeSet();

		ts1.add(78);
		ts1.add(100);
		ts1.add(18);
		ts1.add(98);
		ts1.add(23);
		
		System.out.println(ts1);
		System.out.println("lowest val:"+ts1.pollFirst());
		System.out.println("Highest val:"+ts1.pollLast());


	}

}
